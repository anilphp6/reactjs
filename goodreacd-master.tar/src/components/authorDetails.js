import React from 'react';
import PropTypes from "prop-types";
import renderHTML from 'react-render-html';


const AuthorDetails =({profileData})=>{
	var style = {
		fontWeight:'bold',
	};

	var imageStyle= {
		float:'left', 
		marginRight:'15px'

	}
	console.log(profileData);
	return(
		<div className='book-details col-sm-8 custom-style'>
			<div className='container'>
				<div className="header">
					<h1>Author Details:{profileData.name}</h1>
				</div>
				<div className="container">
					<div className='author-image col-md-6'>
					{ <img src={profileData.image_url.replace("<![CDATA[", "").replace("]]>", "")}/>
					}
					</div>
					<div className='author-details col-md-6'>
						<h1 className='author-title'>{profileData.name}</h1>
						<div className='other-detials'>
							<div>
								<label>Born:</label> 
								{profileData.hometown} at {profileData.born_at}
							</div>
							<div>
								<label>Fans & followers:</label> 
								{profileData.fans_count} and {profileData.author_followers_count}
							</div>
							<div>
								<label>gender:</label> 
								{profileData.gender}
							</div>
							<hr/>
							<div>
								<label>Description:</label> 
								{renderHTML(profileData.about.replace("<![CDATA[", "").replace("]]>", ""))}
							</div>
						</div>	
					</div>
				</div>
			</div>	  
		</div>
);	

}

AuthorDetails.propTypes={
		
		dataDetail: PropTypes.object,

}



export default AuthorDetails;