export const apiKey = 'Y8q84MIDPbzYc2DXy15iOg';
const bookSearchApi = 'https://www.goodreads.com/search/index.xml';
export const  bookDetailsApi ='https://www.goodreads.com/book/isbn';
export const  authorDetailsApi ='https://www.goodreads.com/author/show';

export default bookSearchApi;