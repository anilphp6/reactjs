Poc:Search API


To run this app on local system please follow below mentioned step

1. mkdir "folder name"
2. cd  "folder name" and git clone https://github.com/anilreact/goodreacd.git
3. "npm install"
4. Changes api key or use default in src/config
5. "npm start" after you are abe to see on browser:http://localhost:3000
6. "npm test" (for run test case to all components  )
7. "npm test "component name" to run seperate component test case everty component have .test.js file
8. "npm test Searchbox" for search run searchbox component test case
9. "npm test Datadisplay" for search run Datadisplay component test case (and run api test case)
10. "npm run build" for create deployement on server.




